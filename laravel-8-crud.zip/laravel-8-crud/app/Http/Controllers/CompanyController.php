<?php

namespace App\Http\Controllers;
use App\Models\Company;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class CompanyController extends Controller
{
    /**
    * Display a listing of the resource.
    *
    * @return \Illuminate\Http\Response
    */
    public function index()
    {
        $companies = Company::orderBy('id','desc')->paginate(5);
        return view('companies.index', compact('companies'));
    }

    /**
    * Show the form for creating a new resource.
    *
    * @return \Illuminate\Http\Response
    */
    public function create()
    {
        return view('companies.create');
    }

    /**
    * Store a newly created resource in storage.
    *
    * @param  \Illuminate\Http\Request  $request
    * @return \Illuminate\Http\Response
    */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required',
            'phone' => 'required',
            'dob' => 'required',
            'gender' => 'required',
  	        'photo' => 'mimes:jpeg,jpg,png,gif|required|max:10000', // max 10000kb
            'address' => 'required',
        ]);
        $imageName = time() . '.' . $request->photo->extension();

        $request->photo->move(public_path('images'), $imageName);
        Company::create([
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'dob' => $request->dob,
            'gender' => $request->gender,
            'photo' => $imageName,
            'address' => $request->address,
        ]);

        return redirect()->route('companies.index')->with('success','Account has been created successfully.');
    }

    /**
    * Display the specified resource.
    *
    * @param  \App\company  $company
    * @return \Illuminate\Http\Response
    */
    public function show(Company $company)
    {
        return view('companies.show',compact('company'));
    }

    /**
    * Show the form for editing the specified resource.
    *
    * @param  \App\Company  $company
    * @return \Illuminate\Http\Response
    */
    public function edit(Company $company)
    {
        return view('companies.edit',compact('company'));
    }

    /**
    * Update the specified resource in storage.
    *
    * @param  \Illuminate\Http\Request  $request
    * @param  \App\company  $company
    * @return \Illuminate\Http\Response
    */
    public function update(Request $request, Company $company)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required',
            'phone' => 'required',
            'dob' => 'required',
            'gender' => 'required',
            'hidden_photo' => 'required',
  	        'photo' => 'mimes:jpeg,jpg,png,gif|max:10000', // max 10000kb
            'address' => 'required',
        ]);
		if($request->photo)
		{
			$imagePath = 'images/' . $request->hidden_photo; // Relative path within 'public' folder
			$absolutePath = public_path($imagePath); // Absolute path to the image file

			if (File::exists($absolutePath)) {
				File::delete($absolutePath);
			}
			$imageName = time() . '.' . $request->photo->extension();

			$request->photo->move(public_path('images'), $imageName);
		}
		else
		{
			$imageName = $request->hidden_photo;
		}
        $company->fill([
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'dob' => $request->dob,
            'gender' => $request->gender,
            'photo' => $imageName,
            'address' => $request->address,
        ])->save();

        return redirect()->route('companies.index')->with('success','Account Has Been updated successfully');
    }

    /**
    * Remove the specified resource from storage.
    *
    * @param  \App\Company  $company
    * @return \Illuminate\Http\Response
    */
    public function destroy(Company $company)
    {
		$imagePath = 'images/' . $company->photo; // Relative path within 'public' folder
		$absolutePath = public_path($imagePath); // Absolute path to the image file

		if (File::exists($absolutePath)) {
			File::delete($absolutePath);
		}
        $company->delete();
        return redirect()->route('companies.index')->with('success','Account has been deleted successfully');
    }
}